//
//  ngx_http_google_request.h
//  nginx
//
//  Created by Cube on 14/12/15.
//  Copyright (c) 2014年 Cube. All rights reserved.
//

#ifndef _NGX_HTTP_GOOGLE_REQUEST_H
#define _NGX_HTTP_GOOGLE_REQUEST_H

#include "ngx_http_google_filter_module.h"

ngx_int_t
ngx_http_google_request_handler(ngx_http_request_t * r);

#endif /* defined(_NGX_HTTP_GOOGLE_REQUEST_H) */
